# frozen_string_literal: true

Given(/^I select Login$/) do
    $el1.click!
    $loginTab.click!
  end
  
  When(/^I enter my credentials emailid "([^"]*)",password "([^"]*)"$/) do |_arg1, _arg2|
    $browser.element(:xpath=> "//input[@id='username']").send_keys(_arg1)
    $browser.element(:xpath=> "//input[@id='password']").send_keys(_arg2)
  end
  
  Then(/^I click on Login Button$/) do
    $browser.element(:xpath=> "//button[@id='login-submit']").click
  end
  