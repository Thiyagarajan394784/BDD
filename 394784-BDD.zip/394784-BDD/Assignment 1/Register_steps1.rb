# frozen_string_literal: true

Given(/^I launch the application$/) do
    $browser.element(xpath: "//a[@class='language']").click
  end
  Then(/^I select the country$/) do
    $browser.element(:xpath =>"//a[@title='Austria Deutsch']").click
    $browser.driver.switch_to.window($browser.driver.window_handles[1])
    $browser.element(:xpath => "//button[@id='onetrust-accept-btn-handler']").click!
    $el1.click!
  end
  
  And(/^I click on Register Button$/) do
  
    $browser.element(:xpath=>"//a[@class='responsiveAccountHeader_accountRegister']").click!
  end
  
  When(/^I enter my credentials name "([^"]*)",emailid "([^"]*)",password "([^"]*)" and referral code "([^"]*)"$/) do |_arg1, _arg2, _arg3, _arg4|
    $browser.element(:xpath=>"//input[@id='customerName']").send_keys(_arg1)
    $browser.element(:xpath=>"//input[@id='customerEmail']").send_keys(_arg2)
    $browser.element(:xpath=>"//input[@id='confirmCustomerEmail']").send_keys(_arg2)
    $browser.scroll.to :center
    $browser.element(:xpath=>"//input[@id='customerPassword']").send_keys(_arg3)
    $browser.element(:xpath=>"//input[@id='confirmPassword']").send_keys(_arg3)
    $browser.scroll.to :bottom
    $browser.element(:xpath=>"//input[@id='referrerCode']").send_keys(_arg4)
    $browser.element(:xpath=>"//label[2]").click
  end
  
  
  
  Then(/^I click on continue$/) do
    $browser.element(:xpath=>"//button[@id='continue']").click
  end
  
  