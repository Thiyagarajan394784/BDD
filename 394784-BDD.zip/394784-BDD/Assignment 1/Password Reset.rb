# frozen_string_literal: true

Given(/^I select forgot password$/) do
    $forgotpassword.click
  end
  
  Then(/^I enter my credentials emailid "([^"]*)"$/) do |arg|
    $forgotpwemail.send_keys(arg)
  end
  
  And(/^I click on OK Button$/) do
    $browser.element(:xpath=> "//input[@class='forgottenPasswordModal_dialog_form_submit']").click
  end
  