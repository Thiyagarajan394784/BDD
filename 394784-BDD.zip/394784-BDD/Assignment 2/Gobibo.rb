# frozen_string_literal: true

Given(/^I Launch goibibo website$/) do
    $browser.goto"https://www.goibibo.com/"
  end
  
  When(/^I select One\-way Trip$/) do
    $browser.element(xpath: "//span[@id='oneway']").click
  
  end
  Then(/^I select From "([^"]*)" , Destination "([^"]*)"$/) do |_arg1, _arg2|
    $browser.element(xpath: "//input[@id='gosuggest_inputSrc']").send_keys(_arg1)
    $browser.element(xpath: "//input[@id='gosuggest_inputDest']").send_keys(_arg2)
  
  end
  
  And(/^I Select the Departure date$/) do
    $browser.element(xpath: "//input[@id='departureCalendar']").click
    $browser.element(xpath: "//span[contains(@class,'DayPicker-NavButton DayPicker-NavButton--next')]").click
    $browser.element(xpath: "//div[@id='fare_20200718']").click
  =begin
    $dDate = $driver.element(:xpath => "//div[@class='DayPicker-Months']//div[@class='DayPicker-Month'][1]//div[@class='DayPicker-Caption']/div")
  $month = $dDate.get
  while !$month.contains "August" do
    $browser.element(xpath: "//div[@class='DayPicker-NavBar']//span[@aria-label='Next Month']").click
    $month = dDate.get
  end
    $day = $browser.element(xpath: "//div[@class='DayPicker-Month'][1]//div[3]//div[@class='DayPicker-Day']/div")
    $count = day.size
    $text= null
    for (int) i = 0; i < count; i++) {
        text = day.get(i).get_text();
    if (text.equalsIgnoreCase("23")) {
      day.get(i).click
  break;
  }
  }
  puts "Departure date is selected as " + text + " " + month;
  $depeDate = text + " " + month
  @Date = $depeDate.substring(0, 6)
  end
  =end
  end
  Then(/^I give my travel details$/) do
    $browser.element(xpath: "//span[@id='pax_label']").click
    $browser.element(xpath: " //input[@id='adultPaxBox']").click
    $browser.element(xpath: "//button[@id='adultPaxPlus']").click
    $browser.element(xpath: "//select[@id='gi_class']").click
  end
  
  And(/^Click on Book now Button$/) do
    $browser.element(xpath: "//button[@id='gi_search_btn']").click
    $browser.element(xpath: "//span[contains(@class,'ico13 padR10 padL5')][contains(text(),'Spicejet')]").click
    $browser.element(xpath: "//div[3]//div[1]//div[1]//div[1]//div[2]//span[1]//span[1]//input[1]").click
  end